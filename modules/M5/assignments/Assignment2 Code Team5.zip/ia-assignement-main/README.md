# FastAPI Project

This is a FastAPI project that provides a RESTful API for performing custom search queries using the Google Custom Search API.

Academic Research Online: Finding results on a website based on search terms (e.g., social media or a search engine), extracting the data and sending to an offline location.

## Prerequisites

Before running the project, make sure you have the following installed:

- Python 3.7 or later
- Pip (Python package manager)

## Setup

1. Clone the repository:

```bash
$ git clone https://github.com/samdeniyi/ia-assignement.git
```

2. Navigate to the project directory and create a virtual environment for the project:

```bash
$ cd fastapi-project
$ python3 -m venv env
```
3. Activate the virtual environment:
- For Unix/Linux:
```bash
$ source env/bin/activate
```
- For Windows:
```bash
$ .\env\Scripts\Activate.ps1
```

4. Install the project dependencies:

```bash
$ pip install -r requirements.txt
``` 

5. Create a `.env` file in the root directory of the project and copy the contents of the `sample.env` file into it:

```bash 
$ cp sample.env .env
```
6. Add your Google Custom Search API key and search engine ID to the `.env` file.
- Visit the Google Cloud Console.
- Create a new project or select an existing project.
- Enable the Google Custom Search API for your project.
- Create an API Key and save it.
- Create a Custom Search Engine (CX) and save the CX identifier.
```bash
GOOGLE_SEARCH_API_KEY=YOUR_API_KEY
GOOGLE_SEARCH_ENGINE_ID=YOUR_CX_IDENTIFIER
```

Running the Application
-----------------------
``` bash
$ uvicorn main:app --reload
```
The application will be available at http://localhost:8000.

API Endpoints
-------------

The following API endpoint is available:

- GET /search?q={query}: Performs a custom search query and returns the results in JSON format.


Contributing
------------
If you would like to contribute to this project, please follow these steps:

1. Fork the repository.
2. Create a new branch for your feature or bug fix.
3. Make your changes and commit them.
4. Push the changes to your fork.
5. Submit a pull request.

License
-------
This project is licensed under the MIT License. See the LICENSE file for details.