from typing import List

from fastapi import FastAPI
from factories import SearchFactory
from models import Content
from utils import extract_content_v2, write_to_csv
from fastapi.openapi.utils import get_openapi

app = FastAPI()



def custom_openapi():
	if app.openapi_schema:
		return app.openapi_schema
	openapi_schema = get_openapi(
		title="INTELLIGENT SEARCH ENGINE",
		version="2.5.0",
		description="Academic Research Online: Finding results on a website based on search terms (e.g., social media or a search engine), extracting the data and sending to an offline location.",
		routes=app.routes,
	)
	openapi_schema["info"]["x-logo"] = {
		"url": "https://fastapi.tiangolo.com/img/logo-margin/logo-teal.png"
	}
	app.openapi_schema = openapi_schema
	return app.openapi_schema


app.openapi = custom_openapi


@app.get("/search")
async def search(query: str):
	# call google search and write to csv
	res = await SearchFactory().get_search(query)
	contents: List[Content] = []
	for item in res["items"]:
		content = await extract_content_v2(item["link"])
		if "error" in content:
			continue
		content.update({"query": query, "metadata": item})
		contents.append(content)
	write_to_csv(contents)
	
	# call scale_serp_search and write to csv
	scholar = await SearchFactory().scale_serp_search(query)
	scholar_contents: List[Content] = []
	for item in scholar['scholar_results']:
		scholar_content = await extract_content_v2(item["link"])
		if "error" in scholar_content:
			continue
		scholar_content.update({"query": query, "metadata": item})
		scholar_contents.append(scholar_content)
	write_to_csv(scholar_contents)
	return res["items"]
