from configs import ai_configs as configs
from scholarly import scholarly
import requests
import json


class SearchFactory:
    def __init__(self):
        self.google_search_engine_id = configs.google_search_engine_id
        self.google_search_api_key = configs.google_search_api_key
        self.google_search_url = configs.google_search_url

    async def get_search(self, query: str):
        try:
            parameters = {
                "q": query,
                "cx": self.google_search_engine_id,
                "key": self.google_search_api_key,
            }
            response = requests.get(self.google_search_url, params=parameters)
            return response.json()
        except Exception as e:
            print(str(e))
            return {"error": str(e)}
    
    @staticmethod
    async def scale_serp_search(query: str):
        try:
            params = {
                'api_key': '516EB5AFDC7F47D092F2CB67CCB7E4AE',
                'q': query,
                'search_type': 'scholar'
            }
            api_result = requests.get('https://api.scaleserp.com/search', params)
            return api_result.json()
        except Exception as e:
            print(str(e))
            return {"error": str(e)}
