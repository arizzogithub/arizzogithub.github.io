import logging

import os
from pydantic import BaseSettings
from functools import lru_cache
from dotenv import load_dotenv

load_dotenv()

log = logging.getLogger("uvicorn")


class Settings(BaseSettings):
	google_search_engine_id: str = os.getenv("GOOGLE_SEARCH_ENGINE_ID")
	google_search_api_key: str = os.getenv("GOOGLE_SEARCH_API_KEY")
	google_search_url: str = os.getenv("GOOGLE_SEARCH_URL")
	
	class Config:
		env_file = ".env"


@lru_cache()
def get_settings():
	return Settings()


ai_configs = get_settings()
