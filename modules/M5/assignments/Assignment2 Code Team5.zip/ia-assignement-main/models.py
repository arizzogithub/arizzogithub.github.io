from typing import List, Optional
from pydantic import BaseModel, Field
from datetime import datetime


class Author(BaseModel):
	name: str


class Content(BaseModel):
	query: str
	url: str
	title: str
	summary: str
	authors: List[Author] = []
	publish_date: Optional[datetime] = Field(default=None)
	keywords: List[str] = []
	full_text: str
	metadata: dict = {}
