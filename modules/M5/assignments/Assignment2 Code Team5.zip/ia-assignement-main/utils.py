import requests
from bs4 import BeautifulSoup
import nltk
from newspaper import Article, fulltext

from typing import List

import os
import csv

from models import Content


async def extract_content_v1(url: str):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        text = soup.get_text()
        return text
    except Exception as e:
        print(str(e))
        return {"error": str(e)}


async def extract_content_v2(url: str):
    try:
        article = Article(url)
        article.download()
        article.parse()
        nltk.data.find("tokenizers/punkt")
        article.nlp()
        summary = article.summary
        # text = article.text
        title = article.title
        authors = article.authors
        publish_date = article.publish_date
        keyword = article.keywords
        full_text = fulltext(article.html)
        return {"url": url, "title": title, "summary": summary, "authors": authors, "publish_date": publish_date,
                "keywords": keyword, "full_text": full_text}
    except LookupError:
        nltk.download("punkt")
    except Exception as e:
        print(str(e))
        return {"error": str(e)}


def write_to_csv(data: List[Content]):
    keys = list(Content.__fields__.keys())
    file_path = os.path.join(os.getcwd(), 'data/search_results.csv')
    
    with open(file_path, 'a', newline='') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys)
        # dict_writer.writeheader()
        for item in data:
            if 'authors' in item and item['authors'] is not None:
                item['authors'] = ', '.join(item['authors'])
            else:
                item['authors'] = ''
            if 'keywords' in item and item['keywords'] is not None:
                item['keywords'] = ', '.join(item['keywords'])
            else:
                item['keywords'] = ''
            if 'publish_date' in item and item['publish_date'] is not None:
                item['publish_date'] = item['publish_date'].isoformat()
            else:
                item['publish_date'] = ''
            dict_writer.writerow(item)
